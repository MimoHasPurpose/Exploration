# Spaces

```{eval-rst}
.. automodule:: mesa.space
   :members:
   :inherited-members:
```
